﻿
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace Print_to_PDF
{
    partial class PDF_write_PrintDocument_whj
    {
        public static void PDF_write_PrintDocument(string FullName_导出操作票, List<数据_单个操作任务_类> List_单个操作任务_对象)
        {
            // 选择PDF打印机
            if (List_单个操作任务_对象.Count == 0)
            {
                return;
            }

            try
            {
                string PdfPrinterName = Get_PdfPrinterName(打印配置.打印机名称数组);

                using (PrintDocument printDocument1 = new PrintDocument())
                {
                    printDocument1.PrinterSettings.PrinterName = PdfPrinterName;
                    printDocument1.PrinterSettings.PrintToFile = true;
                    printDocument1.PrinterSettings.PrintFileName = FullName_导出操作票;
                    printDocument1.DocumentName = System.IO.Path.GetFileNameWithoutExtension(FullName_导出操作票);

                    printDocument1.PrintController = new StandardPrintController();

                    //设置页面边距
                    printDocument1.DefaultPageSettings.Margins = new Margins(
                        打印配置.左边距,
                        打印配置.右边距,
                        打印配置.上边距,
                        打印配置.下边距);

                    打印_类 打印_对象 = new 打印_类(List_单个操作任务_对象, printDocument1.DefaultPageSettings);

                    printDocument1.PrintPage += (s, e) => 打印_对象.HandlePrintPage(e);

                    printDocument1.Print();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("打印出错：" + ex.Message);
            }

        }


        public static string Get_PdfPrinterName(string[] PdfPrinterName_cell)
        {
            // 循环打印机
            string PdfPrinterName = "";
            foreach (string printerName in PrinterSettings.InstalledPrinters)
            {
                foreach (string PdfPrinterName_k in PdfPrinterName_cell)
                {
                    if (printerName.Equals(PdfPrinterName_k, StringComparison.OrdinalIgnoreCase))
                    {
                        PdfPrinterName = PdfPrinterName_k;
                        break;
                    }
                }

                if (String.IsNullOrEmpty(PdfPrinterName) == false)
                {
                    break;
                }
            }
            return PdfPrinterName;
        }


    }
}
