﻿using System;
using System.Collections.Generic;
using System.Drawing.Printing;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Print_to_PDF
{
    public static class 打印配置
    {
        // PDF打印机名称数组
        public static readonly string[] 打印机名称数组 = { "Microsoft Print to PDF", "Microsoft 打印到 PDF" };

        // 边距配置
        public const int 左边距 = 30;
        public const int 右边距 = 30;
        public const int 上边距 = 30;
        public const int 下边距 = 34;

        //标签设置
        public const string 标签_变电站 = " 现场电气操作票";
        public const string 标签_操作任务 = "操作任务";

        public const string 表头_操作顺序 = "顺序";
        public const string 表头_操作步骤 = "操作项目";
        public const string 表头_操作 = "操作";

        // 间距配置
        public const float 垂直间距 = 10f;
        public const float 垂直间距比例 = 0.25f;

        // 字体配置
        public static readonly System.Drawing.Font printFont_变电站 = new System.Drawing.Font(System.Windows.Forms.Control.DefaultFont.FontFamily, 18, FontStyle.Bold);

        public static readonly System.Drawing.Font printFont_正文 = new System.Drawing.Font(System.Windows.Forms.Control.DefaultFont.FontFamily, 14);

        public static readonly System.Drawing.Font printFont_操作任务标签 = printFont_正文;
        public static readonly System.Drawing.Font printFont_操作任务 = printFont_正文;

        public static readonly System.Drawing.Font printFont_表头_操作顺序 = printFont_正文;
        public static readonly System.Drawing.Font printFont_表头_操作步骤 = printFont_正文;

        public static readonly System.Drawing.Font printFont_操作顺序 = printFont_正文;
        public static readonly System.Drawing.Font printFont_操作步骤 = printFont_正文;

        public static readonly System.Drawing.Font printFont_页码 = printFont_正文;

        // 颜色配置
        public static readonly Brush brush = Brushes.Black;

        //对齐样式
        public static readonly StringFormat format_自动换行 = new StringFormat
        {
            Trimming = StringTrimming.Word
        };

        public static readonly StringFormat format_自动换行_水平居中 = new StringFormat
        {
            Trimming = StringTrimming.Word,
            Alignment = StringAlignment.Center
        };

        //画笔配置
        public static readonly Pen borderPen = new Pen(Color.Black, 0.5f);


    }
}
