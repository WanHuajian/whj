﻿
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Print_to_PDF
{
    public class 打印_页面绘制_类
    {

        private readonly 打印_页面计算_类 页面计算_对象;

        public 打印_页面绘制_类(打印_页面计算_类 页面计算_对象_input)
        {
            页面计算_对象 = 页面计算_对象_input;
        }


        public void 绘制(Graphics g)
        {
            //新页
            页面计算_对象.分页器_对象.新页();

            绘制上面部分(g);

            绘制操作步骤(g);

            绘制横线(g);

            绘制页码(g);
        }

        private void 绘制上面部分(Graphics g)
        {
            foreach (行_类 行_对象 in 页面计算_对象.List_上面部分_对象)
            {
                行_对象.绘制(g, 页面计算_对象.分页器_对象.y);

                页面计算_对象.分页器_对象.放入(行_对象.height);
            }
        }

        private void 绘制操作步骤(Graphics g)
        {
            while (页面计算_对象.状态管理_对象.是否有当前任务==true)
            {
                页面计算_对象.行组件_对象.计算操作步骤行组件(g);

                页面计算_对象.分页器_对象.计算是否页满(页面计算_对象.行组件_对象.行_操作步骤_对象.height);

                if (页面计算_对象.分页器_对象.是否页满 == true)
                {
                    break;
                }
                else
                {
                    页面计算_对象.行组件_对象.行_操作步骤_对象.绘制(g, 页面计算_对象.分页器_对象.y);
                    页面计算_对象.分页器_对象.放入(页面计算_对象.行组件_对象.行_操作步骤_对象.height);

                    页面计算_对象.状态管理_对象.移至下一操作步骤();
                }
            }
        }

        private void 绘制横线(Graphics g)
        {
            页面计算_对象.行组件_对象.行_横线_对象.绘制(g, 页面计算_对象.分页器_对象.y);
        }


        private void 绘制页码(Graphics g)
        {
            //绘制页面信息
            float y = 页面计算_对象.页面环境_对象.y_底边框 - 页面计算_对象.行组件_对象.行_页码_对象.height;
            页面计算_对象.行组件_对象.行_页码_对象.绘制(g, y);
        }
    }
}
