﻿
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Print_to_PDF
{
    public class 打印_类
    {
        private readonly 打印_状态管理_类 状态管理_对象;
        private readonly 打印_页面计算_类 页面计算_对象;
        private readonly 打印_页面绘制_类 页面绘制_对象;
        
        public 打印_类(List<数据_单个操作任务_类> List_单个操作任务_对象, PageSettings 页面设置)
        {
            状态管理_对象 = new 打印_状态管理_类(List_单个操作任务_对象);

            页面计算_对象 = new 打印_页面计算_类(状态管理_对象,页面设置);

            页面绘制_对象 = new 打印_页面绘制_类(页面计算_对象);
        }
        
        public void HandlePrintPage(PrintPageEventArgs e)
        {
            using (Graphics g = e.Graphics)
            {
                //页面计算
                页面计算_对象.计算页面布局(g);

                //页面绘制
                页面绘制_对象.绘制(g);

                //更新打印状态
                状态管理_对象.更新打印状态();

                //反馈是否需要新页面
                e.HasMorePages = 状态管理_对象.是否需要新页面;
            }
        }
    }
}





