﻿
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Print_to_PDF
{
    public class 行_类
    {
        public readonly List<单元格_类> List_单元格_对象;

        public readonly float height;

        private readonly bool 是否绘制线条;

        private readonly Pen 笔;

        private readonly float[] x_cell;


        public 行_类(List<单元格_类> List_单元格_对象_input, bool 是否绘制线条_input, Pen 笔_input) :
            this(List_单元格_对象_input, 是否绘制线条_input, 笔_input, 计算行高(List_单元格_对象_input))
        {


        }



        public 行_类(List<单元格_类> List_单元格_对象_input,bool 是否绘制线条_input,Pen 笔_input, float height_input)
        {
            List_单元格_对象 = List_单元格_对象_input;

            height = height_input;

            是否绘制线条 = 是否绘制线条_input;
            笔 = 笔_input;

            x_cell = new float[0];
            if (是否绘制线条 == true && List_单元格_对象.Count  != 0)
            {
                x_cell = new float[List_单元格_对象.Count + 1];
                for (int k = 0; k < List_单元格_对象.Count ; k++)
                {
                    x_cell[k] = List_单元格_对象[k].x;
                }
                int lastIndex = List_单元格_对象.Count - 1;
                单元格_类 单元格_最后1个_对象 = List_单元格_对象[lastIndex];
                x_cell[lastIndex + 1] = 单元格_最后1个_对象.x + 单元格_最后1个_对象.width;
            }
        }


        private static float 计算行高(List<单元格_类> List_单元格_对象)
        {
            float height = 0f;

            // 取所有单元格中的最大高度
            foreach (单元格_类 单元格_对象 in List_单元格_对象)
            {
                float height_k =计算行组件_类.Get_行高(单元格_对象.内容高度);

                if (height_k>height)
                {
                    height = height_k;
                }
            }

            return height;
        }


        public void 绘制(Graphics g, float y)
        {
            if (height > 0f)
            {
                foreach (单元格_类 单元格_对象 in List_单元格_对象)
                {
                    单元格_对象.绘制(g, y, height);
                }
            }

            //画横线
            if (x_cell.Length >= 2)
            {
                float x1 = x_cell[0];
                float x2 = x_cell[x_cell.Length - 1];

                Drawing_whj.绘制线条_横线(g, 笔, x1, x2, y);
            }


            if (height > 0f)
            { 
                //画竖线
                foreach (float x in x_cell)
                {
                    float y1 = y;
                    float y2 = y + height;

                    Drawing_whj.绘制线条_竖线(g, 笔, x, y1, y2);
                }
            }
        }





    }
}
