﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Print_to_PDF
{
    public class 单元格_类
    {
        public string 内容 { get; set; }

        private readonly Font 字体;

        private readonly Brush 刷子;

        private readonly StringFormat 字符串格式;


        //矩形框中的内容
        public readonly float x;
        public readonly float width;

        //文本的高度
        public readonly float 内容高度;
        
        public 单元格_类(string 内容_input, Font 字体_input, Brush 刷子_input, StringFormat 字符串格式_input,
            float x_input, float width_input, float 内容高度_input)
        {
            内容 = 内容_input;
            字体 = 字体_input;
            刷子 = 刷子_input;
            字符串格式 = 字符串格式_input;

            x = x_input;
            width = width_input;

            内容高度 = 内容高度_input;
        }


        public void 绘制(Graphics g, float y, float height)
        {
            RectangleF 矩形区域 = new RectangleF(x, y, width, height);

            //绘制变电站
            Drawing_whj.绘制文字至矩形框(g,
                内容,
                字体, 刷子, 字符串格式,
                矩形区域, 内容高度);
        }


    }
}
