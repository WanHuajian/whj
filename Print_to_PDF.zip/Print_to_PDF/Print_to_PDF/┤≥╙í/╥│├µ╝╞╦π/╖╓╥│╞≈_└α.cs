﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Print_to_PDF
{
    public class 分页器_类
    {
        public bool 是否页满 { get; set; }

        private float y_上边框 { get; set; }
        private float y_下边框 { get; set; }

        public float y { get; set; }

        public 分页器_类(float y_上边框_input,float y_下边框_input)
        {
            y_上边框 = y_上边框_input;
            y_下边框 = y_下边框_input;
        }

        // 换页时清零。
        public void 新页()
        {
            y = y_上边框;
            是否页满 = false;
        }

        public void 计算是否页满(float 行高)
        {
            if (y + 行高 <= y_下边框)
            {
                是否页满 = false;
            }
            else
            {
                是否页满 = true;
            }
        }

        public void 放入(float 行高)
        {
            y = y + 行高;
        }


    }
}
