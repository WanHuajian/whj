﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Print_to_PDF
{
    public class 分行器_类
    {
        public float x_左边框 { get; set; }
        public float x_右边框 { get; set; }
        public float x { get; set; }

        public 分行器_类(float x_左边框_input, float x_右边框_input)
        {
            x_左边框 = x_左边框_input;
            x_右边框 = x_右边框_input;
        }

        // 换页时清零。
        public void 新行()
        {
            x = x_左边框;
        }

        public void 放入(float 单元格宽)
        {
            x = x + 单元格宽;
        }
    }
}
