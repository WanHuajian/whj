﻿using System;
using System.Collections.Generic;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Print_to_PDF
{
    public class 页面环境_类
    {
        //环境部分，一直固定
        public float x_左边框 { get; private set; }

        public float x_右边框 { get; private set; }

        public float 宽度 { get; private set; }


        public float y_上边框 { get; private set; }

        public float y_下边框 { get; private set; }

        public float 高度 { get; private set; }



        public float y_底边框 { get; private set; }


        public 页面环境_类(PageSettings 页面设置)
        {
            x_左边框 = 页面设置.Margins.Left;

            x_右边框 = 页面设置.Bounds.Width - 页面设置.Margins.Right;

            宽度 = x_右边框 - x_左边框;



            y_上边框 = 页面设置.Margins.Top;

            y_下边框 = 页面设置.Bounds.Height - 页面设置.Margins.Bottom;

            高度 = y_下边框 - y_上边框;



            y_底边框 = 页面设置.Bounds.Bottom;
        }

    }
}
