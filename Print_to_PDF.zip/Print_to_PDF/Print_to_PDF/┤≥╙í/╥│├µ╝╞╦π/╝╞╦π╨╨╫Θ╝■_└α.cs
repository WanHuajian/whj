﻿
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Print_to_PDF
{
    public class 计算行组件_类
    {
        private readonly 页面环境_类 页面环境_对象;
        private readonly 打印_状态管理_类 状态管理_对象;
        private readonly 分行器_类 分行器_对象;

        public 行_类 行_变电站_对象 { get; set; }

        public 行_类 行_空行_对象 { get; set; }

        public 行_类 行_操作任务_对象 { get; set; }

        public 行_类 行_表头_对象 { get; set; }

        public int 操作步骤单行最大字符个数 { get; set; }

        public 行_类 行_操作步骤_对象 { get; set; }

        public 行_类 行_横线_对象 { get; set; }

        public 行_类 行_页码_对象 { get; set; }



        public 计算行组件_类(页面环境_类 页面环境_对象_input, 打印_状态管理_类 状态管理_对象_input)
        {
            页面环境_对象 = 页面环境_对象_input;

            状态管理_对象 = 状态管理_对象_input;

            分行器_对象 = new 分行器_类(页面环境_对象.x_左边框, 页面环境_对象.x_右边框);
        }


        public static float Get_行高(float textSize_height)
        {
            float height = textSize_height + 打印配置.垂直间距;
            return height;
        }




        public void 计算版面行组件(Graphics g)
        {
            计算变电站信息(g);

            计算空行信息(g);

            计算操作任务信息(g);

            计算表头信息(g);

            计算操作步骤单行最大字符个数(g);

            计算横线信息(g);

            计算页码信息(g);
        }





        public void 计算操作步骤行组件(Graphics g)
        {
            计算操作步骤信息(g);
        }


        private void 计算操作步骤信息(Graphics g)
        {
            分行器_对象.新行();

            单元格_类 单元格_操作顺序_对象 = Get_单元格_操作顺序_对象(状态管理_对象.当前步骤.操作顺序_打印);

            单元格_类 单元格_操作步骤_对象 = Get_单元格_操作步骤_对象(g, 状态管理_对象.当前步骤.操作步骤_打印);

            //行_对象
            List<单元格_类> List_单元格_对象 = new List<单元格_类>();
            List_单元格_对象.Add(单元格_操作顺序_对象);
            List_单元格_对象.Add(单元格_操作步骤_对象);

            bool 是否绘制线条 = true;
            行_操作步骤_对象 = new 行_类(List_单元格_对象, 是否绘制线条, 打印配置.borderPen);
        }


        private 单元格_类 Get_单元格_操作顺序_对象(string 操作顺序_打印)
        {
            float textSize_height = 行_表头_对象.List_单元格_对象[0].内容高度;

            float x = 分行器_对象.x;
            float width = 行_表头_对象.List_单元格_对象[0].width;

            分行器_对象.放入(width);

            单元格_类 单元格_操作顺序_对象 = new 单元格_类(操作顺序_打印,
                打印配置.printFont_操作顺序, 打印配置.brush, 打印配置.format_自动换行_水平居中,
                x, width, textSize_height);

            return 单元格_操作顺序_对象;
        }


        private 单元格_类 Get_单元格_操作步骤_对象(Graphics g,string 操作步骤_打印)
        {
            System.Drawing.Font 字体 = 打印配置.printFont_操作步骤;
            Brush brush = 打印配置.brush;
            StringFormat format = 打印配置.format_自动换行;

            //int 行数 = 0;
            float textSize_height_操作步骤 = 0f;
            if (操作步骤_打印.Length <= 操作步骤单行最大字符个数)
            {
                textSize_height_操作步骤 = 行_表头_对象.List_单元格_对象[0].内容高度;
                //行数 = 1;
            }
            else
            {
                SizeF textSize_操作步骤 = g.MeasureString(
                    操作步骤_打印,
                    字体,
                    new SizeF(行_表头_对象.List_单元格_对象[1].width, float.MaxValue),
                    format);

                textSize_height_操作步骤 = textSize_操作步骤.Height;
            }

            float x = 分行器_对象.x;
            float width = 行_表头_对象.List_单元格_对象[1].width;
            分行器_对象.放入(width);

            单元格_类 单元格_操作步骤_对象 = new 单元格_类(操作步骤_打印,
                字体, brush, format,
                x, width, textSize_height_操作步骤);

            return 单元格_操作步骤_对象;
        }


        private void 计算变电站信息(Graphics g)
        {
            分行器_对象.新行();

            单元格_类 单元格_变电站_对象 = Get_单元格_变电站_对象(g);

            //行_变电站_对象
            List<单元格_类> List_单元格_对象 = new List<单元格_类>();
            List_单元格_对象.Add(单元格_变电站_对象);

            float height_变电站 = 单元格_变电站_对象.内容高度;// Get_行高(单元格_变电站_对象.内容高度);

            bool 是否绘制线条 = false;
            行_变电站_对象 = new 行_类(List_单元格_对象, 是否绘制线条, 打印配置.borderPen, height_变电站);
        }

        private 单元格_类 Get_单元格_变电站_对象(Graphics g)
        {
            string 变电站信息 = 状态管理_对象.当前任务.变电站 + 打印配置.标签_变电站;
            System.Drawing.Font font = 打印配置.printFont_变电站;
            SizeF textSize_变电站 = g.MeasureString(变电站信息, font);
            float textSize_height_变电站 = textSize_变电站.Height;

            float x_变电站 = 分行器_对象.x;
            float width_变电站 = 页面环境_对象.宽度;
            分行器_对象.放入(width_变电站);

            //单元格_对象
            单元格_类 单元格_变电站_对象 = new 单元格_类(变电站信息,
                font, 打印配置.brush, 打印配置.format_自动换行_水平居中,
                x_变电站, width_变电站, textSize_height_变电站);

            return 单元格_变电站_对象;
        }



        private void 计算空行信息(Graphics g)
        {
            分行器_对象.新行();
            单元格_类 单元格_变电站_对象 = Get_单元格_空行_对象(g);

            //行_空行_对象
            List<单元格_类> List_单元格_对象 = new List<单元格_类>();
            List_单元格_对象.Add(单元格_变电站_对象);

            float height_空行 = 单元格_变电站_对象.内容高度;
            bool 是否绘制线条 = false;
            行_空行_对象 = new 行_类(List_单元格_对象, 是否绘制线条, 打印配置.borderPen, height_空行);

        }

        private 单元格_类 Get_单元格_空行_对象(Graphics g)
        {
            string 信息_空行 = " ";
            System.Drawing.Font font = 打印配置.printFont_正文;
            SizeF textSize_空行 = g.MeasureString(信息_空行, font);
            float textSize_height_空行 = textSize_空行.Height;

            float x_空行 = 页面环境_对象.x_左边框;
            float width_空行 = 页面环境_对象.宽度;

            分行器_对象.放入(width_空行);

            //单元格_对象
            单元格_类 单元格_空行_对象 = new 单元格_类(信息_空行,
                font, 打印配置.brush, 打印配置.format_自动换行_水平居中,
                x_空行, width_空行, textSize_height_空行);

            return 单元格_空行_对象;
        }

        private void 计算操作任务信息(Graphics g)
        {
            分行器_对象.新行();
            单元格_类 单元格_操作任务标签_对象 = Get_单元格_操作任务标签_对象(g);

            单元格_类 单元格_操作任务_对象 = Get_单元格_操作任务_对象(g);

            //行_操作任务_对象
            List<单元格_类> List_单元格_对象 = new List<单元格_类>();
            List_单元格_对象.Add(单元格_操作任务标签_对象);
            List_单元格_对象.Add(单元格_操作任务_对象);

            bool 是否绘制线条 = true;
            行_操作任务_对象 = new 行_类(List_单元格_对象, 是否绘制线条, 打印配置.borderPen);
        }

        private 单元格_类 Get_单元格_操作任务标签_对象(Graphics g)
        {
            //操作任务标签
            string 操作任务标签 = 打印配置.标签_操作任务;
            System.Drawing.Font font_操作任务标签 = 打印配置.printFont_操作任务标签;
            SizeF textSize_操作任务标签 = g.MeasureString(操作任务标签, font_操作任务标签);
            float textSize_height_操作任务标签 = textSize_操作任务标签.Height;

            float x_操作任务标签 = 页面环境_对象.x_左边框;
            float width_操作任务标签 = textSize_操作任务标签.Width;

            分行器_对象.放入(width_操作任务标签);

            单元格_类 单元格_操作任务标签_对象 = new 单元格_类(操作任务标签,
                font_操作任务标签, 打印配置.brush, 打印配置.format_自动换行_水平居中,
                x_操作任务标签, width_操作任务标签, textSize_height_操作任务标签);

            return 单元格_操作任务标签_对象;
        }

        private 单元格_类 Get_单元格_操作任务_对象(Graphics g)
        {
            string 操作任务 = 状态管理_对象.当前任务.操作任务;
            System.Drawing.Font font_操作任务 = 打印配置.printFont_操作任务;

            float x_操作任务 = 分行器_对象.x;
            float width_操作任务 = 分行器_对象.x_右边框 - 分行器_对象.x;

            分行器_对象.放入(width_操作任务);

            //操作任务
            SizeF textSize_操作任务 = g.MeasureString(状态管理_对象.当前任务.操作任务,
                font_操作任务,
                new SizeF(width_操作任务, float.MaxValue),
                打印配置.format_自动换行,
                out int charCount,
                out int 行数);

            float textSize_height_操作任务 = textSize_操作任务.Height;

            单元格_类 单元格_操作任务_对象 = new 单元格_类(操作任务,
                font_操作任务, 打印配置.brush, 打印配置.format_自动换行,
                x_操作任务, width_操作任务, textSize_height_操作任务);

            return 单元格_操作任务_对象;
        }



        private void 计算表头信息(Graphics g)
        {
            分行器_对象.新行();

            单元格_类 单元格_表头_操作顺序_对象 = Get_单元格_表头_操作顺序_对象(g);

            单元格_类 单元格_表头_操作步骤_对象 = Get_单元格_表头_操作步骤_对象(g);

            //行_表头_对象
            List<单元格_类> List_表头_对象 = new List<单元格_类>();
            List_表头_对象.Add(单元格_表头_操作顺序_对象);
            List_表头_对象.Add(单元格_表头_操作步骤_对象);

            bool 是否绘制线条_表头 = true;

            行_表头_对象 = new 行_类(List_表头_对象, 是否绘制线条_表头, 打印配置.borderPen);
        }


        private 单元格_类 Get_单元格_表头_操作顺序_对象(Graphics g)
        {
            //width_操作顺序
            string 表头_操作顺序 = 打印配置.表头_操作顺序;
            System.Drawing.Font font = 打印配置.printFont_表头_操作顺序;
            SizeF textSize_操作顺序 = g.MeasureString(表头_操作顺序, font);
            float textSize_height_操作顺序 = textSize_操作顺序.Height;

            //绘制表头_操作顺序
            float x_操作顺序 = 页面环境_对象.x_左边框;

            float width_操作顺序 = 1.5f * textSize_操作顺序.Width;

            分行器_对象.放入(width_操作顺序);

            单元格_类 单元格_表头_操作顺序_对象 = new 单元格_类(表头_操作顺序,
                font, 打印配置.brush, 打印配置.format_自动换行_水平居中,
                x_操作顺序, width_操作顺序, textSize_height_操作顺序);

            return 单元格_表头_操作顺序_对象;
        }


        private 单元格_类 Get_单元格_表头_操作步骤_对象(Graphics g)
        {
            string 表头_操作步骤 = 打印配置.表头_操作步骤;
            System.Drawing.Font font = 打印配置.printFont_表头_操作步骤;
            SizeF textSize_表头_操作步骤 = g.MeasureString(表头_操作步骤, font);
            float textSize_height_表头_操作步骤 = textSize_表头_操作步骤.Height;

            float x_操作步骤 = 分行器_对象.x;
            float width_操作步骤 = 分行器_对象.x_右边框 - 分行器_对象.x;

            分行器_对象.放入(width_操作步骤);

            单元格_类 单元格_表头_操作步骤_对象 = new 单元格_类(表头_操作步骤,
                font, 打印配置.brush, 打印配置.format_自动换行_水平居中,
                x_操作步骤, width_操作步骤, textSize_height_表头_操作步骤);

            return 单元格_表头_操作步骤_对象;
        }




        private void 计算操作步骤单行最大字符个数(Graphics g)
        {
            操作步骤单行最大字符个数 = Drawing_whj.计算单行最大字符个数(g, 打印配置.printFont_操作步骤, 行_表头_对象.List_单元格_对象[1].width);
        }




        private void 计算横线信息(Graphics g)
        {
            单元格_类 单元格_横线_对象 = Get_单元格_横线_对象(g);

            //行_表头_对象
            List<单元格_类> List_对象 = new List<单元格_类>();
            List_对象.Add(单元格_横线_对象);

            bool 是否绘制线条 = true;

            float height = 0f;
            行_横线_对象 = new 行_类(List_对象, 是否绘制线条, 打印配置.borderPen, height);
        }

        private 单元格_类 Get_单元格_横线_对象(Graphics g)
        {
            分行器_对象.新行();

            string 内容 = "";
            System.Drawing.Font font = 打印配置.printFont_正文;
            float textSize_height = 0f;

            //绘制页码
            float x = 分行器_对象.x;
            float width = 分行器_对象.x_右边框 - 分行器_对象.x_左边框;
            分行器_对象.放入(width);

            //单元格_对象
            单元格_类 单元格_横线_对象 = new 单元格_类(内容,
                font, 打印配置.brush, 打印配置.format_自动换行_水平居中,
                x, width, textSize_height);

            return 单元格_横线_对象;
        }




        private void 计算页码信息(Graphics g)
        {
            单元格_类 单元格_页码_对象 = Get_单元格_页码_对象(g);

            //行_表头_对象
            List<单元格_类> List_对象 = new List<单元格_类>();
            List_对象.Add(单元格_页码_对象);

            bool 是否绘制线条 = false;

            行_页码_对象 = new 行_类(List_对象, 是否绘制线条, 打印配置.borderPen);
        }

        private 单元格_类 Get_单元格_页码_对象(Graphics g)
        {
            分行器_对象.新行();

            string 页码信息 = Get_页码信息(状态管理_对象.页码_所有任务);
            System.Drawing.Font font = 打印配置.printFont_页码;
            SizeF textSize_页码 = g.MeasureString(页码信息, font);
            float textSize_height_页码 = textSize_页码.Height;

            //绘制页码
            float x = 分行器_对象.x;
            float width = 分行器_对象.x_右边框 - 分行器_对象.x_左边框;
            分行器_对象.放入(width);

            //单元格_对象
            单元格_类 单元格_页码_对象 = new 单元格_类(页码信息,
                font, 打印配置.brush, 打印配置.format_自动换行_水平居中,
                x, width, textSize_height_页码);

            return 单元格_页码_对象;
        }

        public void 更新页码信息()
        {
            行_页码_对象.List_单元格_对象[0].内容 = 计算行组件_类.Get_页码信息(状态管理_对象.页码_所有任务);
        }

        public static string Get_页码信息(int 页码)
        {
            string 页码信息 = "第" + 页码.ToString() + "页";
            return 页码信息;
        }





    }
}
