﻿
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Print_to_PDF
{
    public class 打印_页面计算_类
    {
        //不可变依赖
        public readonly 打印_状态管理_类 状态管理_对象;

        public readonly 页面环境_类 页面环境_对象;

        public readonly 分页器_类 分页器_对象;

        public readonly 计算行组件_类 行组件_对象;

        //可变状态
        public List<行_类> List_上面部分_对象 { get;private set; }

        public 打印_页面计算_类(打印_状态管理_类 状态管理_对象_input, PageSettings 页面设置)
        {
            状态管理_对象 = 状态管理_对象_input;

            页面环境_对象 = new 页面环境_类(页面设置);

            分页器_对象 = new 分页器_类(页面环境_对象.y_上边框, 页面环境_对象.y_下边框);

            行组件_对象 = new 计算行组件_类(页面环境_对象, 状态管理_对象);

            List_上面部分_对象 = new List<行_类>();
        }

        public void 计算页面布局(Graphics g)
        {
            //页面布局计算
            if (状态管理_对象.页码_当前任务 == 1)
            {
                行组件_对象.计算版面行组件(g);
            }

            //更新页码
            行组件_对象.更新页码信息();

            //计算_List_上面部分_对象
            计算_List_上面部分_对象();
        }



        private void 计算_List_上面部分_对象()
        {
            //不区分首页与非首页的上面部分
            if (状态管理_对象.页码_当前任务 == 1)
            {
                List_上面部分_对象.Clear();
                List_上面部分_对象.Add(行组件_对象.行_变电站_对象);
                List_上面部分_对象.Add(行组件_对象.行_空行_对象);
                List_上面部分_对象.Add(行组件_对象.行_操作任务_对象);
                List_上面部分_对象.Add(行组件_对象.行_表头_对象);
            }

            ////区分首页与非首页的上面部分
            //if (状态管理_对象.页码_当前任务 == 1)
            //{
            //    List_上面部分_对象.Clear();
            //    List_上面部分_对象.Add(行组件_对象.行_变电站_对象);
            //    List_上面部分_对象.Add(行组件_对象.行_空行_对象);
            //    List_上面部分_对象.Add(行组件_对象.行_操作任务_对象);
            //    List_上面部分_对象.Add(行组件_对象.行_表头_对象);
            //}
            //else if (状态管理_对象.页码_当前任务 == 2)
            //{
            //    List_上面部分_对象.Clear();
            //    List_上面部分_对象.Add(行组件_对象.行_表头_对象);
            //}
        }
    }
}
