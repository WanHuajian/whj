﻿
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Print_to_PDF
{
    public class 打印_状态管理_类
    {
        //不可变字段
        private readonly List<数据_单个操作任务_类> List_单个操作任务_对象;

        //可变字段
        private int 操作任务索引 { get; set; }
        private int 操作步骤索引 { get; set; }

        public int 页码_所有任务 { get;private set; }
        public int 页码_当前任务 { get; private set; }

        public bool 是否需要新页面 { get; set; }

        //计算属性
        public 数据_单个操作任务_类 当前任务 => List_单个操作任务_对象[操作任务索引];
        public 数据_操作顺序及操作步骤_类 当前步骤 => 当前任务.List_操作顺序及操作步骤_对象[操作步骤索引];
        public bool 是否有当前任务 => 操作步骤索引 <= 当前任务.List_操作顺序及操作步骤_对象.Count - 1;
        private bool 是否有后续任务 => 操作任务索引 <= List_单个操作任务_对象.Count - 2;

        public 打印_状态管理_类(List<数据_单个操作任务_类> List_单个操作任务_对象_input)
        {
            List_单个操作任务_对象 = List_单个操作任务_对象_input;

            操作任务索引 = 0;
            操作步骤索引 = 0;

            页码_所有任务 = 1;
            页码_当前任务 = 1;
        }

        public void 更新打印状态()
        {
            是否需要新页面 = false;

            //判断是否需要新页面，并切换任务
            if (是否有当前任务 == true)
            {
                是否需要新页面 = true;
            }
            else
            {
                if (是否有后续任务 == true)
                {
                    是否需要新页面 = true;

                    // 移动到下一个任务
                    移至下一操作任务();
                }
                else
                {
                    //任务全部完成
                    是否需要新页面 = false;
                }
            }


            //更新页码
            if (是否需要新页面 == true)
            {
                页码_所有任务 = 页码_所有任务 + 1;

                if (操作步骤索引 == 0)
                {
                    页码_当前任务 = 1;
                }
                else
                {
                    页码_当前任务 = 页码_当前任务 + 1;
                }
            }
        }


        private void 移至下一操作任务()
        {
            操作任务索引 = 操作任务索引 + 1;

            操作步骤索引 = 0;
        }

        public void 移至下一操作步骤()
        {
            操作步骤索引 = 操作步骤索引 + 1;
        }
    }
}
