﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Print_to_PDF
{
    public class 数据_操作顺序及操作步骤_类
    {
        public string 操作顺序_打印 { get; set; }

        public string 操作步骤_打印 { get; set; }

        public static List<数据_操作顺序及操作步骤_类> Get_List_操作顺序及操作步骤_对象(string[] tline_cell)
        {
            List<数据_操作顺序及操作步骤_类> List_操作顺序及操作步骤_对象 = new List<数据_操作顺序及操作步骤_类>();

            int a = 0;
            int b = 0;

            foreach (string tline_k in tline_cell)
            {
                string tline = tline_k.Trim();

                if (String.IsNullOrEmpty(tline) == false)
                {
                    string 操作顺序_打印 = "";
                    string 操作步骤_打印 = "";

                    if (tline.StartsWith("$") == false)
                    {
                        a = a + 1;
                        b = 0;

                        操作顺序_打印 = a.ToString();
                        操作步骤_打印 = tline;
                    }
                    else
                    {
                        b = b + 1;

                        操作顺序_打印 = "";
                        操作步骤_打印 = b.ToString() + ")" + tline.Substring(1);
                    }

                    数据_操作顺序及操作步骤_类 操作顺序及操作步骤_对象 = new 数据_操作顺序及操作步骤_类();
                    操作顺序及操作步骤_对象.操作顺序_打印 = 操作顺序_打印;
                    操作顺序及操作步骤_对象.操作步骤_打印 = 操作步骤_打印;

                    List_操作顺序及操作步骤_对象.Add(操作顺序及操作步骤_对象);
                }
            }

            return List_操作顺序及操作步骤_对象;

        }
    }
}
