﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Print_to_PDF
{
    public class 数据_单个操作任务_类
    {
        public string 变电站 { get; set; }
        public string 操作任务 { get; set; }
        public List<数据_操作顺序及操作步骤_类> List_操作顺序及操作步骤_对象 { get; set; }

    }
}
