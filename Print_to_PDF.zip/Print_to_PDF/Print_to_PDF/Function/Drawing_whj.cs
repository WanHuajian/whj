﻿
using System;
using System.Drawing;
using System.Drawing.Printing;
using System.Text;
using System.Windows.Forms;

namespace Print_to_PDF
{
    class Drawing_whj
    {

        //统计字符宽度
        public static int Get_str_width(Control control_object, string str, System.Drawing.Font font)
        {
            System.Drawing.Graphics formGraphics = control_object.CreateGraphics();
            //System.Drawing.Graphics formGraphics = this.dataGridview_Init.CreateGraphics();

            System.Drawing.SizeF sizeF = formGraphics.MeasureString(str, font);
            //统计尾部空格的个数
            int n_blank = 0;
            char[] str_cell = str.ToCharArray();
            for (int k = str_cell.Length - 1; k >= 0; k--)
            {
                char c = str_cell[k];
                if (c == ' ')
                {
                    n_blank = n_blank + 1;
                }
                else
                {
                    break;
                }
            }
            int Label_Width = Convert.ToInt32(Math.Round(sizeF.Width * 0.97 + n_blank * 6));
            return Label_Width;
        }


        public static void 绘制文字至矩形框(Graphics g,
            string text,
            Font font,
            Brush brush,
            StringFormat format,
            RectangleF rect,
            float textSize_Height)
        {
            float y_文字 = rect.Top + (rect.Height - textSize_Height) / 2f + 打印配置.垂直间距 * 打印配置.垂直间距比例;

            g.DrawString(text,
                font,
                brush,
                new RectangleF(rect.X,
                y_文字,
                rect.Width,
                textSize_Height),
                format);

        }


        public static void 绘制线条_横线(Graphics g,Pen pen_object, float x1, float x2, float y)
        {
            // 在页码底部画一条横线                    
            g.DrawLine(
                pen_object,
                x1,
                y,
                x2,
                y);
        }


        public static void 绘制线条_竖线(Graphics g, Pen pen_object, float x, float y1, float y2)
        {
            //画竖线
            g.DrawLine(
                pen_object,
                x,
                y1,
                x,
                y2);

        }






        public static int 计算单行最大字符个数(Graphics g,Font 字体, float 总宽度)
        {
            char 测试字符 = '测';

            float 平均字符宽度 = Get_平均字符宽度(g, 测试字符, 字体);

            int 操作步骤单行最大字符个数 = Convert.ToInt32(Math.Floor(总宽度 / 平均字符宽度));

            StringBuilder stringBuilder_object = new StringBuilder(new string(测试字符, 操作步骤单行最大字符个数));
            SizeF currentSize = g.MeasureString(stringBuilder_object.ToString(), 字体);

            int 循环次数上限 = 操作步骤单行最大字符个数+10;
            if (currentSize.Width < 总宽度)
            {
                操作步骤单行最大字符个数 = 向上查找(g, 测试字符, 字体, ref stringBuilder_object,  总宽度, 循环次数上限);
            }
            else if (currentSize.Width > 总宽度)
            {
                操作步骤单行最大字符个数 = 向下查找(g, 字体, ref stringBuilder_object, 总宽度, 循环次数上限);
            }
            else
            {
                //操作步骤单行最大字符个数 = 操作步骤单行最大字符个数;
            }

            return 操作步骤单行最大字符个数;
        }


        public static float Get_平均字符宽度(Graphics g, char 测试字符, System.Drawing.Font font)
        {
            // 测量1个字符
            int 字符个数 = 10;
            string 十个字符 = new string(测试字符, 字符个数);
            float 十字符总宽度 = g.MeasureString(十个字符, font).Width;
            float 平均字符宽度 = 十字符总宽度 / (float)字符个数;

            return 平均字符宽度;
        }

        private static int 向上查找(Graphics g, char 测试字符, Font 字体, ref StringBuilder stringBuilder_object, float width_操作步骤, int 循环次数上限)
        {
            for (int k = 0; k < 循环次数上限; k++)
            {
                stringBuilder_object.Append(测试字符);

                SizeF currentSize = g.MeasureString(stringBuilder_object.ToString(), 字体);

                if (currentSize.Width > width_操作步骤)
                {
                    stringBuilder_object.Length = stringBuilder_object.Length - 1;
                    break;
                }
            }

            return stringBuilder_object.Length;
        }


        private static int 向下查找(Graphics g, Font 字体, ref StringBuilder stringBuilder_object, float width_操作步骤, int 循环次数上限)
        {
            for (int k = 0; k < 循环次数上限; k++)
            {
                if (stringBuilder_object.Length <= 1)
                {
                    break;
                }

                stringBuilder_object.Length = stringBuilder_object.Length - 1;

                SizeF currentSize = g.MeasureString(stringBuilder_object.ToString(), 字体);

                if (currentSize.Width <= width_操作步骤)
                {
                    break;
                }
            }

            return stringBuilder_object.Length;
        }



    }
}
